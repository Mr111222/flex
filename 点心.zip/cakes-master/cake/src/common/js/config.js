export default {
    baseUrl : 'http://10.130.147.211:8081',
    lang : [
        {
            text: '简体中文',
            value: 'ZH'
        }, {
            text: 'English',
            value: 'EN'
        }
    ]
}
